# 25 + 5 Clock

A Pen created on CodePen.io. Original URL: [https://codepen.io/shera11/pen/ZEoWmEp](https://codepen.io/shera11/pen/ZEoWmEp).

